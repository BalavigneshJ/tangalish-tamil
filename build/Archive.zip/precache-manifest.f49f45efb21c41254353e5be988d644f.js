self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8ee83a993fe477279d39f3104622d071",
    "url": "/thanglish-tamil/index.html"
  },
  {
    "revision": "f9e74d111114a4d6bcc8",
    "url": "/thanglish-tamil/static/css/main.6321ae9f.chunk.css"
  },
  {
    "revision": "23fb7a696a2f943ceb24",
    "url": "/thanglish-tamil/static/js/2.2beee410.chunk.js"
  },
  {
    "revision": "f9e74d111114a4d6bcc8",
    "url": "/thanglish-tamil/static/js/main.36b3a415.chunk.js"
  },
  {
    "revision": "20330d9d845d7ce01308",
    "url": "/thanglish-tamil/static/js/runtime-main.65567573.js"
  }
]);